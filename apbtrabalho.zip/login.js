

<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.10.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.10.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDJLR5h7vI4EFC01FwlT8iWp4H_f4cV9Rc",
    authDomain: "fir-loginomi.firebaseapp.com",
    projectId: "fir-loginomi",
    storageBucket: "fir-loginomi.appspot.com",
    messagingSenderId: "1090679680153",
    appId: "1:1090679680153:web:87024db15024468dbcdc08",
    measurementId: "G-TYZDE8MTYZ"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>
